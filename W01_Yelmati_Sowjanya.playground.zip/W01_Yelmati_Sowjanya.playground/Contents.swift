//: Playground - noun: a place where people can play
//  Name: Sowjanya Yelmati
//  CWID: A11810493
//  Assignment Number: Assignment 1
//  Course: 4153
//  Swift code that converts octal number to decimal number

import UIKit

var octal:Int = 345, i: Double = 0, decimal:Int = 0
var output:String = " "

//while loop which checks if the input is octal number , if yes converts to decimal else prints number is not octal
while octal != 0
{
    decimal = decimal + (octal % 10) * Int(pow(8, i))
    if octal % 10 > 7
    {
        output = "Input number is not a valid Octal number"
        break
    }
    else
    {
        i = i + 1
        octal = octal / 10
        output = "Decimal number equivalent for given octal number is \(decimal)"
    }
}

print("\(output)")
