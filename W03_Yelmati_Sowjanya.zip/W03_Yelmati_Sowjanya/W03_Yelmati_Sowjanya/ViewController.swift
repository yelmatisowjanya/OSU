//  ViewController.swift
// W03_Yelmati_Sowjanya
// Name         :   Sowjanya Yelmati
// CWID         :   A11810493
// Assignment   :   Weekly Assignment 3
// Course       :   CS4153
//  Copyright © 2017 Sowjanya Yelmati. All rights reserved.

import UIKit

var label1_flag = false
var label1_initialPosition : CGPoint = CGPoint.zero
var label2_flag = false
var label2_initialPosition : CGPoint = CGPoint.zero
var label3_flag = false
var label3_initialPosition : CGPoint = CGPoint.zero
var fretArray: [(chordName:String, fourthString: Int, thirdString: Int, secondString: Int, firstString: Int)] = []
var labelArray: [String] = ["ChordLabel1","ChordLabel2","ChordLabel3"]
var correctLabel : String = ""
var labelName : String = " "
var score = 0
var scoreFlag = false

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        fretArray += [("C",0,0,0,3)]
        fretArray += [("D",2,2,2,0)]
        fretArray += [("F",2,0,1,0)]
        fretArray += [("G",0,2,3,2)]
        fretArray += [("A",2,1,0,0)]
        fretArray += [("Dm",2,2,1,0)]
        fretArray += [("Em",0,4,3,2)]
        fretArray += [("Fm",1,0,1,3)]
        fretArray += [("Gm",0,2,3,1)]
        fretArray += [("Am",2,0,0,0)]
        fretArray += [("C7",0,0,0,1)]
        fretArray += [("G7",0,2,1,2)]
        randomLabelSelection()
        scoreLabel.text = "0"
        resultLabel.text = " "
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBOutlet weak var ChordLabel1: UILabel!
    
    @IBOutlet weak var ChordLabel2: UILabel!
    
    @IBOutlet weak var ChordLabel3: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var fourthStringDot: UIImageView!
    
    @IBOutlet weak var thirdStringDot: UIImageView!
    
    @IBOutlet weak var secondStringDot: UIImageView!
    
    @IBOutlet weak var firstStringDot: UIImageView!
    
    
    // Pan Gesture Recognizer action for Label 3
    @IBAction func label3PanGestureRecognizer(_ sender: UIPanGestureRecognizer) {

        if label3_flag == false
        {
            label3_initialPosition = ChordLabel3.center
            label3_flag = true
        }
         if sender.state == .changed
         {
            let distance = sender.translation(in: self.view)
            
            if let view = sender.view
            {
                view.center = CGPoint(x:view.center.x + distance.x,        y:view.center.y + distance.y)
            }
            sender.setTranslation(CGPoint.zero, in: self.view)
         }
        else if sender.state == .ended
         {
            if label3_initialPosition != nil
            {
                ChordLabel3.center = label3_initialPosition
            }
            self.ChordLabel3.setNeedsUpdateConstraints()
        }
        
        if labelName == "ChordLabel3" && scoreFlag == false
        {
            resultLabel.text = "Correct!"
            score = score + 1
            scoreLabel.text = String(score)
            scoreFlag = true
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
        else if scoreFlag == false
        {
            resultLabel.text = "Sorry, the correct answer was \(correctLabel)"
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
    }
    
    // Pan Gesture Recognizer action for Label 2
    @IBAction func label2PanGestureRecognizer(_ sender: UIPanGestureRecognizer) {

        if label2_flag == false
        {
            label2_initialPosition = ChordLabel2.center
            label2_flag = true
        }
        if sender.state == .changed
        {
            let distance = sender.translation(in: self.view)
            if let view = sender.view
            {
                view.center = CGPoint(x:view.center.x + distance.x,        y:view.center.y + distance.y)
            }
            sender.setTranslation(CGPoint.zero, in: self.view)
        }
        else if sender.state == .ended
        {
            if label2_initialPosition != nil
            {
                ChordLabel2.center = label2_initialPosition
            }
            self.ChordLabel2.setNeedsUpdateConstraints()
        }
        
        if labelName == "ChordLabel2" && scoreFlag == false
        {
            resultLabel.text = "Correct!"
            score = score + 1
            scoreLabel.text = String(score)
            scoreFlag = true
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
        else if scoreFlag == false
        {
            resultLabel.text = "Sorry, the correct answer was \(correctLabel)"
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
        
    }
    
    // Pan Gesture Recognizer action for Label 1
    @IBAction func label1PanGestureRecognizer(_ sender: UIPanGestureRecognizer) {
        if label1_flag == false
        {
            label1_initialPosition = ChordLabel1.center
            label1_flag = true
        }
        if sender.state == .changed
        {
            let distance = sender.translation(in: self.view)
            
            if let view = sender.view
            {
                view.center = CGPoint(x:view.center.x + distance.x,        y:view.center.y + distance.y)
            }
            sender.setTranslation(CGPoint.zero, in: self.view)
        }
        else if sender.state == .ended
        {
            if label1_initialPosition != nil
            {
                ChordLabel1.center = label1_initialPosition
            }
            self.ChordLabel1.setNeedsUpdateConstraints()
        }
        
        if labelName == "ChordLabel1" && scoreFlag == false
        {
            resultLabel.text = "Correct!"
            score = score + 1
            scoreLabel.text = String(score)
            scoreFlag = true
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
        else if scoreFlag == false
        {
            resultLabel.text = "Sorry, the correct answer was \(correctLabel)"
            ChordLabel1.isUserInteractionEnabled = false
            ChordLabel2.isUserInteractionEnabled = false
            ChordLabel3.isUserInteractionEnabled = false
        }
        
    }
    
    // Tap Gesture Recognizer action when the user taps anywhere on the screen
    @IBAction func screenTapGesture(_ sender: UITapGestureRecognizer) {
        scoreFlag = false
        resultLabel.text = " "
        ChordLabel1.isUserInteractionEnabled = true
        ChordLabel2.isUserInteractionEnabled = true
        ChordLabel3.isUserInteractionEnabled = true
        ChordLabel1.text = "Label"
        ChordLabel2.text = "Label"
        ChordLabel3.text = "Label"
        randomLabelSelection()
    }
    
    // This function selects a label randomly from the array and displays on the fret board
    func randomLabelSelection()
    {
        var randomChord = Int(arc4random_uniform(UInt32(fretArray.count)))
        var randomLabel = Int(arc4random_uniform(UInt32(labelArray.count)))
        var newRandomArray = fretArray.filter { $0 != fretArray[randomChord] }
        
        if labelArray[randomLabel] == "ChordLabel1"
        {
            ChordLabel1.text = fretArray[randomChord].chordName
            correctLabel = fretArray[randomChord].chordName
            labelName = "ChordLabel1"
        }
        else if labelArray[randomLabel] == "ChordLabel2"
        {
            ChordLabel2.text = fretArray[randomChord].chordName
            correctLabel = fretArray[randomChord].chordName
            labelName = "ChordLabel2"
        }
        else if labelArray[randomLabel] == "ChordLabel3"
        {
            ChordLabel3.text = fretArray[randomChord].chordName
            correctLabel = fretArray[randomChord].chordName
            labelName = "ChordLabel3"
        }
        
        
         if ChordLabel1.text == "Label"
         {
            var firstRandom = Int(arc4random_uniform(UInt32(newRandomArray.count)))
            ChordLabel1.text = newRandomArray[firstRandom].chordName
            newRandomArray = newRandomArray.filter { $0 != newRandomArray[firstRandom] }
         }
        if ChordLabel2.text == "Label"
        {
            var secondRandom = Int(arc4random_uniform(UInt32(newRandomArray.count)))
            ChordLabel2.text = newRandomArray[secondRandom].chordName
            newRandomArray = newRandomArray.filter { $0 != newRandomArray[secondRandom] }
        }
        if ChordLabel3.text == "Label"
        {
            var thirdRandom = Int(arc4random_uniform(UInt32(newRandomArray.count)))
            ChordLabel3.text = newRandomArray[thirdRandom].chordName
            newRandomArray = newRandomArray.filter { $0 != newRandomArray[thirdRandom] }
        }
        placingDotsOnBoard()
    }
    
    
    // This function finds the co-ordinates of frets on the board and places dots in the appropriate position
    func placingDotsOnBoard()
    {
        fourthStringDot.isHidden = true
        thirdStringDot.isHidden = true
        secondStringDot.isHidden = true
        firstStringDot.isHidden = true
        
        let frame = CGRect(x: 37, y: 45, width: 29, height: 30)
        let view = UIView(frame: frame)
        
        for arrayElements in fretArray
        {
            if arrayElements.chordName == correctLabel
            {
                if arrayElements.fourthString == 0
                {
                    fourthStringDot.isHidden = true
                }
                else if arrayElements.fourthString == 1
                {
                    fourthStringDot.isHidden = false
                    fourthStringDot.frame.origin.y = 150
                }
                else if arrayElements.fourthString == 2
                {
                    fourthStringDot.isHidden = false
                    fourthStringDot.frame.origin.y = 230
                }
                else if arrayElements.fourthString == 3
                {
                    fourthStringDot.isHidden = false
                    fourthStringDot.frame.origin.y = 310
                }
                else if arrayElements.fourthString == 4
                {
                    fourthStringDot.isHidden = false
                    fourthStringDot.frame.origin.y = 400
                }
                else if arrayElements.fourthString == 5
                {
                    fourthStringDot.isHidden = false
                    fourthStringDot.frame.origin.y = 480
                }
                
                
                if arrayElements.thirdString == 0
                {
                    thirdStringDot.isHidden = true
                }
                else if arrayElements.thirdString == 1
                {
                    thirdStringDot.isHidden = false
                    thirdStringDot.frame.origin.y = 150
                }
                else if arrayElements.thirdString == 2
                {
                    thirdStringDot.isHidden = false
                    thirdStringDot.frame.origin.y = 230
                }
                else if arrayElements.thirdString == 3
                {
                    thirdStringDot.isHidden = false
                    thirdStringDot.frame.origin.y = 310
                }
                else if arrayElements.thirdString == 4
                {
                    thirdStringDot.isHidden = false
                    thirdStringDot.frame.origin.y = 400
                }
                else if arrayElements.thirdString == 5
                {
                    thirdStringDot.isHidden = false
                    thirdStringDot.frame.origin.y = 480
                }
                
                
                
                if arrayElements.secondString == 0
                {
                    secondStringDot.isHidden = true
                }
                else if arrayElements.secondString == 1
                {
                    secondStringDot.isHidden = false
                    secondStringDot.frame.origin.y = 150
                }
                else if arrayElements.secondString == 2
                {
                    secondStringDot.isHidden = false
                    secondStringDot.frame.origin.y = 230
                }
                else if arrayElements.secondString == 3
                {
                    secondStringDot.isHidden = false
                    secondStringDot.frame.origin.y = 310
                }
                else if arrayElements.secondString == 4
                {
                    secondStringDot.isHidden = false
                    secondStringDot.frame.origin.y = 400
                }
                else if arrayElements.secondString == 5
                {
                    secondStringDot.isHidden = false
                    secondStringDot.frame.origin.y = 480
                }
                
                
                if arrayElements.firstString == 0
                {
                    firstStringDot.isHidden = true
                }
                else if arrayElements.firstString == 1
                {
                    firstStringDot.isHidden = false
                    firstStringDot.frame.origin.y = 150
                }
                else if arrayElements.firstString == 2
                {
                    firstStringDot.isHidden = false
                    firstStringDot.frame.origin.y = 230
                }
                else if arrayElements.firstString == 3
                {
                    firstStringDot.isHidden = false
                    firstStringDot.frame.origin.y = 310
                }
                else if arrayElements.firstString == 4
                {
                    firstStringDot.isHidden = false
                    firstStringDot.frame.origin.y = 400
                }
                else if arrayElements.firstString == 5
                {
                    firstStringDot.isHidden = false
                    firstStringDot.frame.origin.y = 480
                }
                
                
            }
        }
        
        
        
        
    }
    
    
    
    
    
    
}

