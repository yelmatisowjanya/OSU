// This program displays a UI which lets the user convert measurements between fluid ounces and milliliters
//Name       :  Sowjanya Yelmati
//Course     :  CS4153
//Assignment :  Weely Assignment 2(W02_Yelmati_Sowjanya)
//CWID       :  A11810493
//  Copyright © 2017 Sowjanya Yelmati. All rights reserved.

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var labelDisplay: UITextField!
    
    @IBOutlet weak var One: UIButton!
    
    @IBOutlet weak var Two: UIButton!
    
    @IBOutlet weak var Three: UIButton!
    
    @IBOutlet weak var Four: UIButton!
    
    @IBOutlet weak var Five: UIButton!
    
    @IBOutlet weak var Six: UIButton!
    
    @IBOutlet weak var Seven: UIButton!
    
    @IBOutlet weak var Eight: UIButton!
    
    @IBOutlet weak var Nine: UIButton!
    
    @IBOutlet weak var Zero: UIButton!
    
    @IBOutlet weak var oz: UIButton!
    
    @IBOutlet weak var ml: UIButton!
    
    @IBOutlet weak var Clear: UIButton!
    
    @IBOutlet weak var Decimal: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
     //Action when digit button is clicked.
    @IBAction func digitButtonTapped(_ sender: UIButton) {
        var buttonTapped = sender.titleLabel?.text
        
        if labelDisplay.text == "0"
        {
            labelDisplay.text = buttonTapped
        }
        else
        {
            labelDisplay.text = (labelDisplay.text)!+buttonTapped!
        }
 
    }
    
    //Action when clear button is clicked.
    @IBAction func clearButtonTapped(_ sender: UIButton) {
        labelDisplay.text = "0"
        One.isEnabled = true
        Two.isEnabled = true
        Three.isEnabled = true
        Four.isEnabled = true
        Five.isEnabled = true
        Six.isEnabled = true
        Seven.isEnabled = true
        Eight.isEnabled = true
        Nine.isEnabled = true
        Zero.isEnabled = true
        oz.isEnabled = true
        ml.isEnabled = true
        Decimal.isEnabled = true
    }
    
    //Action when oz button is clicked.
    @IBAction func ozButtonClicked(_ sender: UIButton) {
        labelDisplay.text = String(Double(labelDisplay.text!)! / 29.5735296)
        One.isEnabled = false
        Two.isEnabled = false
        Three.isEnabled = false
        Four.isEnabled = false
        Five.isEnabled = false
        Six.isEnabled = false
        Seven.isEnabled = false
        Eight.isEnabled = false
        Nine.isEnabled = false
        Zero.isEnabled = false
        oz.isEnabled = false
        ml.isEnabled = false
        Decimal.isEnabled = false
    }
    
     //Action when ml button is clicked.
    @IBAction func mlButtonClicked(_ sender: UIButton) {
        labelDisplay.text = String(Double(labelDisplay.text!)! * 29.5735296)
        One.isEnabled = false
        Two.isEnabled = false
        Three.isEnabled = false
        Four.isEnabled = false
        Five.isEnabled = false
        Six.isEnabled = false
        Seven.isEnabled = false
        Eight.isEnabled = false
        Nine.isEnabled = false
        Zero.isEnabled = false
        oz.isEnabled = false
        ml.isEnabled = false
        Decimal.isEnabled = false
    }
    
     //Action when "." button is clicked.
    @IBAction func decimalButtonTapped(_ sender: UIButton) {
        
        if (labelDisplay.text?.contains("."))!
        {
            Decimal.isEnabled = false
        }
        else
        {
            if labelDisplay.text == "0"
            {
                labelDisplay.text = "0."
            }
            else
            {
                labelDisplay.text = (labelDisplay.text)! + "."
            }
        }
        
    }
    
    
}

