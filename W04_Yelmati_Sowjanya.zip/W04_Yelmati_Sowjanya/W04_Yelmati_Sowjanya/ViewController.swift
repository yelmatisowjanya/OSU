//
//  ViewController.swift
//  W04_Yelmati_Sowjanya
//
//  Created by Sowjanya Yelmati on 9/17/17.
//  Copyright © 2017 Sowjanya Yelmati. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

