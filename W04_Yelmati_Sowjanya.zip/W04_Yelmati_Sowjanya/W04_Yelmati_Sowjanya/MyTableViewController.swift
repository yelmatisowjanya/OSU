//  W04_Yelmati_Sowjanya
// Name         :   Sowjanya Yelmati
// CWID         :   A11810493
// Assignment   :   Weekly Assignment 4
// Course       :   CS4153

//  Created by Sowjanya Yelmati on 9/17/17.
//  Copyright © 2017 Sowjanya Yelmati. All rights reserved.

import UIKit

//This function is used to shuffle the elements in array
  extension Array
    {
        mutating func shuffle()
        {
            for _ in 0..<10
            {
                sort { (_,_) in arc4random() < arc4random() }
            }
        }
    }

//This table view controller is used to display a table with sections and rows
class MyTableViewController: UITableViewController {
    var fretArray = [ (chordName:"C", frets:"0003"),
                      (chordName:"D",frets:"2220"),
                      (chordName:"F",frets:"2010"),
                      (chordName:"G",frets:"0232"),
                      (chordName:"A",frets:"2100"),
                      (chordName:"Dm",frets:"2210"),
                      (chordName:"Em",frets:"0432"),
                      (chordName:"Fm",frets:"1013"),
                      (chordName:"Gm",frets:"0231"),
                      (chordName:"Am",frets:"2000"),
                      (chordName:"C7",frets:"0001"),
                      (chordName:"G7",frets:"0212")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return fretArray.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Configure the cell...
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        // To display title and subtitle
        let cellData: (chordName: String, frets: String) = fretArray[indexPath[0]]
        cell.textLabel?.text = cellData.chordName
        cell.detailTextLabel?.text = cellData.frets
        return cell
    }
    
    //This method makes the view controller respond to touch events
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    //Actual shake can be detected with this method
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            fretArray.shuffle()
            self.tableView.reloadData()
        }
    }
    
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
